package com.company.map;

public class Desert {
}
