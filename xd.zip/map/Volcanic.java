package com.company.map;

public class Volcanic {
}
